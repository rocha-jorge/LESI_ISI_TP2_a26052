﻿namespace BitcoinApp.Models
{
    public class Role
    {
        public int idRole { get; set; }
        public string roleDescription { get; set; }
    }
}
