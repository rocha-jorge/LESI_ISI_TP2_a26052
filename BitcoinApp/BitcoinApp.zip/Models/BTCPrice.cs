﻿namespace BitcoinApp.Models
{
    public class BTCPrice
    {
        public DateTime btcTimeStamp { get; set; }
        public float price { get; set; }
    }
}
